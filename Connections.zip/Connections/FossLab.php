<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_FossLab = "127.0.0.1";
$database_FossLab = "fosslab";
$username_FossLab = "steffy";
$password_FossLab = "123";
$FossLab = mysql_pconnect($hostname_FossLab, $username_FossLab, $password_FossLab) or trigger_error(mysql_error(),E_USER_ERROR); 
?>